class Address {
  String id;
  String title;

  Address({
    this.id,
    this.title,
  });
}
