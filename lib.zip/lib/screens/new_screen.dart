import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';

import '../proba/location_controller.dart';
import '../proba/map_screen.dart';

class MapView extends StatefulWidget {
  @override
  State<MapView> createState() => _MapViewState();
}

class _MapViewState extends State<MapView> {
  @override
  Widget build(BuildContext context) {
    Get.put(LocationController());
    return GetMaterialApp(debugShowCheckedModeBanner: false, home: MapScreen());
  }
}
